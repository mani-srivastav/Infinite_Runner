<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
    
<footer class="bg-body-tertiary text-center text-lg-start">
  <!-- Copyright -->
  <div class="text-center p-3" style="background-color: #3CB371;color: black;
font-size: 18px;
font-family: Comic San MS;">
    © 2025 Copyright Created by Mani Srivastava
  </div>
  <!-- Copyright -->
</footer>