<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@page import="runner.beans.*"%>
<%@page import="runner.dao.*"%>
<%@page import="java.util.*"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Infinite Runner</title>
    <%@include file="/common/common_css.html"  %>

    <style>
        body {
            background-image: url('/InfiniteRunner/images/GameBackground.jpeg');
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', sans-serif;
        }

        .glass-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            align-items: center;
            background: rgba(255, 255, 255, 0.12);
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            border-radius: 20px;
            padding: 40px;
            margin: 5vh auto;
            max-width: 1200px;
            width: 95%;
            box-shadow: 0 0 25px rgba(255,255,255,0.2);
            animation: fadeIn 1.5s ease-in-out;
            transition: all 0.3s ease;
        }

        .glass-container:hover {
            transform: scale(1.01);
            box-shadow: 0 0 30px rgba(255,255,255,0.3);
        }

        .game-description {
            flex: 1 1 50%;
            color: white;
            padding: 20px;
            box-sizing: border-box;
        }

        .game-description h1 {
            font-size: 3.5em;
            margin-bottom: 20px;
            color: #fff;
            text-shadow: 2px 2px 6px rgba(0,0,0,0.7);
        }

        .game-description p {
            font-size: 1.2em;
            line-height: 1.8;
            color: #eee;
            text-shadow: 1px 1px 4px rgba(0,0,0,0.5);
        }

        .highlight {
            color: #00ffd0;
            font-weight: bold;
        }

        .game-image {
            flex: 1 1 45%;
            padding: 20px;
            animation: slideIn 1.5s ease;
            box-sizing: border-box;
        }

        .game-image img {
            width: 100%;
            border-radius: 20px;
            box-shadow: 0 0 15px rgba(0,0,0,0.5);
            transition: transform 0.4s ease;
        }

        .game-image img:hover {
            transform: scale(1.05);
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes slideIn {
            from { transform: translateX(50px); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }

        @media (max-width: 768px) {
            .glass-container {
                flex-direction: column;
                padding: 20px;
            }

            .game-description, .game-image {
                flex: 1 1 100%;
                text-align: center;
            }

            .game-description h1 {
                font-size: 2.2em;
            }

            .game-description p {
                font-size: 1em;
            }
        }
    </style>
</head>

<body>
    <div class="main-div">
        <%@include file="/common/header.html"%>

        <div class="glass-container">
            <div class="game-image">
                <img src="/InfiniteRunner/images/imageofgame.jpg" alt="Infinite Runner Game">
            </div>

            <div class="game-description">
                <h1>Infinite Runner</h1>
                <p>
                    <span class="highlight">Run endlessly</span> through a futuristic world full of obstacles and mystery. 
                    In <span class="highlight">Infinite Runner</span>, you must <span class="highlight">react fast</span>, 
                    jump over hurdles, and collect power-ups to stay ahead.
                </p>
                <p>
                    With <span class="highlight">vibrant animations</span>, <span class="highlight">progressive speed</span>, 
                    and <span class="highlight">reflex-testing mechanics</span>, this game will keep your heart racing. 
                    Whether you’re a beginner or a hardcore gamer, there’s always more to conquer.
                </p>
                <p>
                    Get ready to <span class="highlight">challenge your limits</span> and become the top runner!
                </p>
            </div>
        </div>
    </div>

    <%@include file="/common/footer.jsp" %>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-ndDqU0Gzau9qJ1lfW4pNLlhNTkCfHzAVBReH9diLvGRem5+R9g2FzA8ZGN954O5Q"
    crossorigin="anonymous"></script>
</body>
</html>
