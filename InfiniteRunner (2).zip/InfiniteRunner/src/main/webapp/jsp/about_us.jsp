<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Infinite Runner</title>
<%@include file="/common/common_css.html"%>

<style type="text/css">
.container {
	display: flex;
	flex-direction: column;
	height: 600px;
}

.boxes {
	display: flex;
	gap: 40px;
}
</style>
</head>
<body style="background-image: url(/InfiniteRunner/images/GameBackground.jpeg); background-repeat: no-repeat; background-size: cover">
	<div class="main-div">
		<%@include file="/common/header.html"%>
		<div class="container">
			<div class="boxes">
				<div style="margin-top: 35px">
					<img style="width: 200px; height: 180px; border-radius: 50%;"
						alt="" src="/InfiniteRunner/images/ourgoals.png">
				</div>
				<div style="margin-top: 35px; width: 1000px">
					<p
						style="font-size: 20px; font-family: Comic San MS; font-style: italic; color: white">The
						primary goal of the Infinite Runner project is to develop an
						engaging and dynamic game that challenges players to navigate
						through an endless environment while avoiding obstacles and
						collecting points. This project aims to enhance programming and
						game development skills by applying key concepts such as
						object-oriented programming, adaptive difficulty, and real-time
						rendering. By incorporating adaptive difficulty, the game ensures
						that the level of challenge scales with the player’s performance,
						maintaining excitement and promoting longer engagement.
				</div>
			</div>
			<div class="boxes">
				<div style="margin-top: 10px">
					<img style="width: 200px; height: 180px; border-radius: 50%;"
						alt="" src="/InfiniteRunner/images/projectVision.png">
				</div>
				<div style="margin-top: 10px; width: 1000px">
					<p
						style="font-size: 20px; font-family: Comic San MS; font-style: italic; color: white">The
						vision of the Infinite Runner project is to create a high-quality,
						interactive, and endlessly engaging game that serves as a
						foundation for learning and innovation in software development.
						This project envisions a platform where creativity meets
						technology, allowing users and developers to explore the
						possibilities of game mechanics, real-time interaction, and
						full-stack application integration. It aims to inspire budding
						developers to push the boundaries of what they can build, turning
						simple ideas into advanced, scalable, and enjoyable digital
						experiences.
				</div>
			</div>
			<div class="boxes">
				<div style="margin-top: 10px">
					<img style="width: 200px; height: 180px; border-radius: 50%;"
						alt="" src="/InfiniteRunner/images/projectMission.png">
				</div>
				<div style="margin-top: 10px; width: 1000px">
					<p
						style="font-size: 20px; font-family: Comic San MS; font-style: italic; color: white">The
						mission of the Infinite Runner project is to design and develop a
						feature-rich, adaptive endless runner game using full-stack
						technologies. Our goal is to provide learners with a comprehensive
						platform that enhances technical skills in Java, frontend
						frameworks, backend integration, and user interaction. By
						completing this project, developers will gain the confidence and
						competence needed to tackle real-world challenges in software and
						game development, preparing them for future academic or
						professional pursuits.
				</div>
			</div>
		</div>
	</div>
	<%@include file="/common/footer.jsp"%>
	<script
		src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"
		integrity="sha384-ndDqU0Gzau9qJ1lfW4pNLlhNTkCfHzAVBReH9diLvGRem5+R9g2FzA8ZGN954O5Q"
		crossorigin="anonymous"></script>
</body>
</html>