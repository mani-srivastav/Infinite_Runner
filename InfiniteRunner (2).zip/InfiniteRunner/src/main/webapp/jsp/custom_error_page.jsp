<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8" isErrorPage="true"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Infinite Runner - Error</title>
<style>
    body {
        background-color: #0f2027;
        background-image: linear-gradient(315deg, #0f2027, #203a43, #2c5364);
        color: white;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 100vh;
        margin: 0;
        text-align: center;
    }

    h1 {
        font-size: 3rem;
        margin-bottom: 10px;
        animation: fadeInDown 1s ease-in-out;
    }

    p {
        font-size: 1.2rem;
        margin-bottom: 20px;
        animation: fadeIn 2s ease-in-out;
    }

    .btn {
        background-color: #ff4b5c;
        color: white;
        padding: 10px 20px;
        border: none;
        font-size: 1rem;
        border-radius: 25px;
        cursor: pointer;
        transition: 0.3s;
        text-decoration: none;
    }

    .btn:hover {
        background-color: #ff1e40;
        transform: scale(1.05);
    }

    @keyframes fadeInDown {
        from { opacity: 0; transform: translateY(-30px); }
        to { opacity: 1; transform: translateY(0); }
    }

    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }
</style>
</head>
<body>
    <h1>Oops! Server is busy</h1>
    <p>Something went wrong on our end. Please try again later.</p>
    <a href="index.jsp" class="btn">Go Back Home</a>
</body>
</html>
