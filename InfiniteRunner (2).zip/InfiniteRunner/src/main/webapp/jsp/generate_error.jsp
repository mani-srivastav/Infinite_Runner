<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Infinite Runner</title>
</head>
<body>
<%
 String name=null;
System.out.println(name.length());
out.println(name.length());
%>
</body>
</html>