<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>

<%@page import="runner.beans.*"%>
<!-- jsp me paackage import ho rha hai -->
<%@page import="runner.dao.*"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<%@include file="/common/common_css.html"%>
<body
	style="background-image: url(/InfiniteRunner/images/background.jpg); background-repeat: no-repeat; background-size: cover">
	<%
	String userEmail = (String) session.getAttribute("sessionKey");
	String userRole = (String) session.getAttribute("role");
	if (userEmail != null && userRole.equals("user")) {
		UserDao dao = new UserDao();
		UserDetails user = dao.userProfile(userEmail);
		String uploadPath = request.getContextPath();
		String imageUrl = uploadPath + "/" + user.getProfile_pic();
	%>

	<%@include file="/user/user_header.html"%>
	<div class="main-div">
		<div class="container-fluid"
			style="background-color: lime; margin-top: 70px">

			<h2 style="text-align: center;">
				Hello
				<%=user.getName()%>🙋‍♂️🙋‍♂️
			</h2>
		</div>
		<h4>
			Email:<%=user.getEmail()%></h4>
		<img width="150px" height="150px" alt="" src="<%=imageUrl%>">

		<form method="post" action="/InfiniteRunner/UserEditProfile">

			<div
				style="width: 400px; height: 450px; background-color: pink; margin: auto">
				<h4>Phone Number:</h4>
				<input type="text" name="phone" required class="form-control"
					value="<%=user.getPhone()%>">
				<h4>City:</h4>
				<input type="text" name="phone" required class="form-control"
					value="<%=user.getCity()%>">
			</div>
			<div class="text-center">
<button class="btn btn-danger">Submit</button></div>
		</form>


	</div>
	<%@include file="/common/footer.jsp"%>


	<%
	} else {
	request.setAttribute("message", "UnAuthorized Access");
	RequestDispatcher rd = request.getRequestDispatcher("/user/user_login.jsp");
	rd.forward(request, response);
	}
	%>
	<script
		src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"
		integrity="sha384-ndDqU0Gzau9qJ1lfW4pNLlhNTkCfHzAVBReH9diLvGRem5+R9g2FzA8ZGN954O5Q"
		crossorigin="anonymous"></script>
</body>
</html>