<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Infinite Runner</title>
<%@include file="/common/common_css.html"  %>
</head>
<body style="background-image: url(/InfiniteRunner/images/GameBackground.jpeg); background-repeat: no-repeat; background-size: cover">
<div class="main-div">
<%@include file="/common/header.html" %>
<div style="text-align: center;margin-top: 40px">
			<h1 style="color:white;font-family: Comic San MS;">User Login</h1>
		</div>
<div class="w-25 mx-auto mt-5">
<form class="needs-validation" novalidate="novalidate" method="post" action="/InfiniteRunner/UserLogin">
				
				<div class="input-group mb-3">
					<span class="input-group-text"><i class="fa-solid fa-envelope"></i>
					</span> <input required="required" type="email" name="email"
						class="form-control" placeholder="Email">
						<div class="invalid-feedback">Enter your Email.</div>
				</div>
				<div class="input-group mb-3">
					<span class="input-group-text"><i class="fa-solid fa-key"></i></i>
					</span> <input required="required" type="password" name="password"
						class="form-control" placeholder="password">
						<div class="invalid-feedback">Enter your Password.</div>
				</div>
				
				<div class="text-center">
					<button class="btn btn-danger">
						<i class="fa-solid fa-lock"></i> Submit
					</button>
				</div>
			</form>
			<br>
			<% String msg=(String)request.getAttribute("message"); 
     if(msg!=null){ %>
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
  <strong><%=msg %></strong> 
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
    <% } %> 
</div>

</div>
<%@include file="/common/footer.jsp" %>
	<script src="/InfiniteRunner/javascript/validation.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js" integrity="sha384-ndDqU0Gzau9qJ1lfW4pNLlhNTkCfHzAVBReH9diLvGRem5+R9g2FzA8ZGN954O5Q" crossorigin="anonymous"></script>
</body>
</html>