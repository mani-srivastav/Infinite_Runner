<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<%@include file="/common/common_css.html"%>
</head>
<body style="background-image: url(/InfiniteRunner/images/GameBackground.jpeg); background-repeat: no-repeat; background-size: cover">

<div class="main-div">
		<%@include file="/user/user_header.html"%>
<div style="margin: 50px auto; max-width: 1000px; padding: 30px; background: rgba(255, 255, 255, 0.6); border-radius: 20px; backdrop-filter: blur(10px); color: black; font-family: 'Segoe UI', sans-serif; box-shadow: 0 0 20px rgba(0,0,0,0.1);">

  <h1 style="text-align: center; font-size: 2.8rem; font-style: italic; border-bottom: 2px solid black; padding-bottom: 10px;">🎮 Infinite Runner Game</h1>

  <p style="margin-top: 20px; font-size: 1.1rem;">A modern, responsive infinite runner game built using <b>HTML5 Canvas</b>, <b>CSS3</b>, and <b>JavaScript</b>. Features immersive gameplay, layered backgrounds, and multiple difficulty levels for all skill levels.</p>

  <h2 style="margin-top: 30px; border-left: 5px solid black; padding-left: 10px;">🚀 Features</h2>
  <ul>
    <li>Endless gameplay with increasing difficulty</li>
    <li>Multiple difficulty modes: Easy, Medium, Hard</li>
    <li>Jump using <b>SPACE</b> to avoid obstacles</li>
    <li>Collect coins to increase score</li>
    <li>Lives system and distance tracking</li>
  </ul>

  <h2 style="margin-top: 30px; border-left: 5px solid black; padding-left: 10px;">🎨 Visual Effects</h2>
  <ul>
    <li>Parallax animated background</li>
    <li>Jump and coin collection particle effects</li>
    <li>3D-like depth via layered visuals</li>
    <li>Glassmorphism UI with responsive design</li>
  </ul>

  <h2 style="margin-top: 30px; border-left: 5px solid black; padding-left: 10px;">🎯 Difficulty Levels</h2>
  <table style="width: 100%; margin-top: 10px; border-collapse: collapse; text-align: left;">
    <thead>
      <tr style="background-color: rgba(0,0,0,0.1);">
        <th style="padding: 10px;">Mode</th>
        <th style="padding: 10px;">Lives</th>
        <th style="padding: 10px;">Speed</th>
        <th style="padding: 10px;">Coins</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td style="padding: 10px;">Easy</td>
        <td style="padding: 10px;">3</td>
        <td style="padding: 10px;">Low</td>
        <td style="padding: 10px;">More</td>
      </tr>
      <tr>
        <td style="padding: 10px;">Medium</td>
        <td style="padding: 10px;">2</td>
        <td style="padding: 10px;">Medium</td>
        <td style="padding: 10px;">Balanced</td>
      </tr>
      <tr>
        <td style="padding: 10px;">Hard</td>
        <td style="padding: 10px;">1</td>
        <td style="padding: 10px;">High</td>
        <td style="padding: 10px;">Few</td>
      </tr>
    </tbody>
  </table>

  <h2 style="margin-top: 30px; border-left: 5px solid black; padding-left: 10px;">🕹 How to Play</h2>
  <ol>
    <li>Open <code>index.html</code> in browser</li>
    <li>Select difficulty mode</li>
    <li>Press <b>SPACE</b> to jump, <b>ESC</b> to pause/resume</li>
    <li>Avoid obstacles & collect coins</li>
    <li>Score based on distance and coins</li>
  </ol>

  <h2 style="margin-top: 30px; border-left: 5px solid black; padding-left: 10px;">🎮 Game Elements</h2>
  <ul>
    <li><b>Player</b>: Red rectangle with golden eyes, jump-enabled</li>
    <li><b>Obstacles</b>: Rocks, Trees, Red Spikes</li>
    <li><b>Collectibles</b>: Rotating golden coins</li>
    <li><b>Background</b>: Gradient sky, parallax layers, brown ground</li>
  </ul>

  <h2 style="margin-top: 30px; border-left: 5px solid black; padding-left: 10px;">🛠 Technical Features</h2>
  <ul>
    <li>requestAnimationFrame for smooth rendering</li>
    <li>Optimized collision detection</li>
    <li>Object pooling for particle performance</li>
    <li>Responsive to all screen sizes</li>
  </ul>

  <h2 style="margin-top: 30px; border-left: 5px solid black; padding-left: 10px;">📁 File Structure</h2>
  <pre style="background: rgba(0,0,0,0.05); padding: 15px; border-radius: 10px;">
runner-game/
├── index.html      # Main HTML file
├── style.css       # CSS styles and animations
├── script.js       # Game logic and mechanics
└── README.md       # This file
  </pre>

  <h2 style="margin-top: 30px; border-left: 5px solid black; padding-left: 10px;">🎨 Customization</h2>
  <ul>
    <li>Change colors in CSS</li>
    <li>Adjust speed & spawn rates</li>
    <li>Add custom animations or sound</li>
  </ul>

  <h2 style="margin-top: 30px; border-left: 5px solid black; padding-left: 10px;">🚧 Future Enhancements</h2>
  <ul>
    <li>Sound effects and music</li>
    <li>Character skins and power-ups</li>
    <li>Leaderboard & touch controls</li>
    <li>Dynamic background themes</li>
  </ul>

  <p style="margin-top: 30px; font-style: italic; text-align: center;">Created using HTML5 Canvas, CSS3 & Vanilla JS. No external libraries required!</p>
</div>











</div>
	<%@include file="/user/user_footer.jsp"%>
<script
		src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"
		integrity="sha384-ndDqU0Gzau9qJ1lfW4pNLlhNTkCfHzAVBReH9diLvGRem5+R9g2FzA8ZGN954O5Q"
		crossorigin="anonymous"></script>
</body>
</html>