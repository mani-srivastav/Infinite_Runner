<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
	
	<%@page import="runner.beans.*" %>  <!-- jsp me paackage import ho rha hai -->
	<%@page import="runner.dao.*" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Infinite Runner</title>
<style>
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        color: white;
    }

    h1.title-clean {
        font-size: 48px;
        font-weight: 700;
        font-style: italic;
        color: #ffffff;
        text-align: center;
        margin-top: 60px;
        letter-spacing: 2px;
        text-transform: uppercase;
        text-shadow: 
            -1px -1px 0 #000,  
             1px -1px 0 #000,
            -1px  1px 0 #000,
             1px  1px 0 #000;
    }

    .menu-container {
        margin-top: 40px;
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    .menu-btn {
        width: 220px;
        height: 50px;
        margin: 10px 0;
        background: transparent;
        border: 2px solid white;
        border-radius: 10px;
        transition: 0.3s ease-in-out;
    }

    .menu-btn:hover {
        background-color: rgba(255, 255, 255, 0.2);
        transform: scale(1.05);
    }

    .menu-btn a {
        font-size: 18px;
        font-weight: bold;
        font-style: italic;
        color: white;
        text-decoration: none;
        display: block;
        width: 100%;
        height: 100%;
        line-height: 46px;
        text-align: center;
        text-shadow: 
            -1px -1px 0 #000,  
             1px -1px 0 #000,
            -1px  1px 0 #000,
             1px  1px 0 #000;
    }
</style>
</head>
<%@include file="/common/common_css.html"%>
<body style="background-image: url(/InfiniteRunner/images/GameBackground.jpeg); background-repeat: no-repeat; background-size: cover">
	<%
	String userEmail = (String) session.getAttribute("sessionKey");
	String userRole = (String) session.getAttribute("role");
	if (userEmail != null && userRole.equals("user")) {
		UserDao dao = new UserDao();
		UserDetails user = dao.userProfile(userEmail);
	%>
	<%@include file="/user/user_header.html"%>
	<div
	 class="main-div">
   <nav class="navbar navbar-light fixed-top" style="background-color:#3CB371;">
    <div class="container-fluid">
        
        <a class="navbar-brand mx-auto" href="#"><i class="fa-solid fa-face-smile"></i> Welcome</a>
    </div>
</nav>


    
    
    <div style="text-align: center; margin-top: 120px">
        <h1 class="title-clean">Infinite Runner</h1>
    </div>

    <div class="menu-container">
        <button class="menu-btn"><a href="/InfiniteRunner/user/game/game.jsp">Play Game</a></button>
        <button class="menu-btn"><a href="/InfiniteRunner/user/game_rules.jsp">Rules</a></button>
        <button class="menu-btn"><a href="#">View Score</a></button>
        <button class="menu-btn"><a href="/InfiniteRunner/user/user_feedback.jsp">FeedBack</a></button>
        <button class="menu-btn"><a href="/InfiniteRunner/UserLogout">Logout</a></button>
    </div>
    <%
			String msg = (String) request.getAttribute("message");
			if (msg != null) {
			%>
			<div class="alert alert-warning alert-dismissible fade show"
				role="alert">
				<strong><%=msg%></strong>
				<button type="button" class="btn-close" data-bs-dismiss="alert"
					aria-label="Close"></button>
			</div>
			<%
			}
			%>
</div>
	<%@include file="/user/user_footer.jsp"%>
	<%
	} else {
	request.setAttribute("message", "UnAuthorized Access");
	RequestDispatcher rd = request.getRequestDispatcher("/user/user_login.jsp");
	rd.forward(request, response);
	}
	%>
	
	
	<script
		src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"
		integrity="sha384-ndDqU0Gzau9qJ1lfW4pNLlhNTkCfHzAVBReH9diLvGRem5+R9g2FzA8ZGN954O5Q"
		crossorigin="anonymous"></script>
</body>
</html>