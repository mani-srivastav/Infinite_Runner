<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<%@page import="runner.beans.*"%>
<%@page import="runner.dao.*"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Infinite Runner</title>
<%@include file="/common/common_css.html"%>
<style type="text/css">
.star-rating {
	display: flex;
	justify-content: center;
	margin: 15px 0;
	direction: rtl;
}

.star-rating input[type="radio"] {
	display: none;
}

.star-rating label {
	font-size: 30px;
	color: #ccc;
	padding: 0 5px;
	cursor: pointer;
	transition: color 0.3s;
}

.star-rating input:checked ~ label, .star-rating label:hover,
	.star-rating label:hover ~ label {
	color: #ffc107;
}
</style>
</head>
<body style="background-image: url(/InfiniteRunner/images/GameBackground.jpeg); background-repeat: no-repeat; background-size: cover">
	<%
	String userEmail = (String) session.getAttribute("sessionKey");
	String userRole = (String) session.getAttribute("role");
	if (userEmail != null && userRole.equals("user")) {
		UserDao dao = new UserDao();
		UserDetails user = dao.userProfile(userEmail);
	%>

	<div class="main-div">
		<%@include file="/user/user_header.html"%>
		<div style="text-align: center; margin-top: 100px">
			<h1 style="color: white; font-family: Comic San MS;">FeedBack</h1>
		</div>
		<div class="w-25 mx-auto mt-5">
			<form class="needs-validation" novalidate="novalidate" method="post"
				action="/InfiniteRunner/UserFeedBack">
				<div class="input-group mb-3">
					<span class="input-group-text"><i
						class="fa-solid fa-envelope"></i> </span> <input required="required"
						type="email" name="email" value="<%=user.getEmail()%>"
						readonly="readonly" class="form-control" placeholder="Email">
						<div class="invalid-feedback">Enter your Email.</div>
				</div>
				<div class="input-group mb-3">
					<span class="input-group-text"><i
						class="fa-solid fa-circle-user"></i> </span> <input required="required"
						type="text" name="name" class="form-control"
						value="<%=user.getName()%>" placeholder="Name">
						<div class="invalid-feedback">Enter your Name.</div>
				</div>
				<div class="input-group mb-3">
					<span class="input-group-text"><i
						class="fa-solid fa-message"></i> </span>
					<textarea class="form-control" required="required" name="remarks" placeholder="Remarks"
						style="height: 100px"></textarea>
						<div class="invalid-feedback">Enter your Remarks.</div>
				</div>
				<div class="star-rating">
					<div class="input-group-text">
						<input type="radio" id="star5" name="rating" value="5"> <label
							for="star5">&#9733;</label> <input type="radio" id="star4"
							name="rating" value="4"> <label for="star4">&#9733;</label>
						<input type="radio" id="star3" name="rating" value="3"> <label
							for="star3">&#9733;</label> <input type="radio" id="star2"
							name="rating" value="2"> <label for="star2">&#9733;</label>
						<input type="radio" id="star1" name="rating" value="1"> <label
							for="star1">&#9733;</label>
							<div class="invalid-feedback">Select Ratings.</div>
					</div>
				</div>
				<div class="text-center">
					<button class="btn btn-danger">
						<i class="fa-solid fa-lock"></i> Submit
					</button>
				</div>
			</form>
			<br>
			<%
			String msg = (String) request.getAttribute("message");
			if (msg != null) {
			%>
			<div class="alert alert-warning alert-dismissible fade show"
				role="alert">
				<strong><%=msg%></strong>
				<button type="button" class="btn-close" data-bs-dismiss="alert"
					aria-label="Close"></button>
			</div>
			<%
			}
			%>
		</div>

	</div>


	<%@include file="/user/user_footer.jsp"%>
	<%
	} else {
	request.setAttribute("message", "UnAuthorized Access");
	RequestDispatcher rd = request.getRequestDispatcher("/user/user_login.jsp");
	rd.forward(request, response);
	}
	%>
	<script src="/InfiniteRunner/javascript/validation.js"></script>
	<script
		src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"
		integrity="sha384-ndDqU0Gzau9qJ1lfW4pNLlhNTkCfHzAVBReH9diLvGRem5+R9g2FzA8ZGN954O5Q"
		crossorigin="anonymous"></script>
</body>
</html>