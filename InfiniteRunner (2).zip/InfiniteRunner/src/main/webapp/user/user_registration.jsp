<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Infinite Runner</title>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    
    
    <script>
    $(document).ready(function(){
    	
    	$("#email").change(function(){
			
    		 let userEmail=$(this).val()
    		// alert(userEmail)
       
   $.ajax({

	url:"/InfiniteRunner/UserRegistration",
	type:"GET",
	data:{"uEmail":userEmail},
	
	success:function(responseData){
	//alert(responseData)
	if(responseData=="true")
		{
		$("#ajaxMsg").text("Email Already Exists")
	//alert(userEmail+ " Already exists")
	
	 setTimeout(function(){

		$("#email").val("")
		$("#ajaxMsg").text("")
		},1000) 
		}//if close
		
		
		
	}//success  object function close

 })//ajax function close 

    		    
 
    	})//on change close
  
    
    })//documentReady close

    
    
    
    
    </script>

</head>
<%@include file="/common/common_css.html"%>
<body style="background-image: url(/InfiniteRunner/images/GameBackground.jpeg); background-repeat: no-repeat; background-size: cover">
	<div class="main-div">
		<%@include file="/common/header.html"%>
		<div style="text-align: center; margin-top: 40px">
			<h1 style="color: white; font-family: Comic San MS;">Registration
				Form</h1>
		</div>
		<div class="w-25 mx-auto mt-5">
			<form class="needs-validation" method="post"
				action="/InfiniteRunner/UserRegistration"
				enctype="multipart/form-data" novalidate="novalidate">
				<div class="input-group mb-3">
					<span class="input-group-text"><i
						class="fa-solid fa-envelope"></i> </span> <input required="required"
						type="email" name="email" id="email" class="form-control" placeholder="Email">
					<div class="invalid-feedback">Enter your Email.</div>
					
				</div>
					<span id="ajaxMsg" style="color:white ;font-size: 15px"></span>
				<div class="input-group mb-3">
					<span class="input-group-text"><i class="fa-solid fa-key"></i>
					</span> <input required="required" type="password" name="password"
						class="form-control" placeholder="Password">
					<div class="invalid-feedback">Enter your Password.</div>
				</div>
				<div class="input-group mb-3">
					<span class="input-group-text"><i
						class="fa-solid fa-circle-user"></i> </span> <input required="required"
						type="text" name="name" class="form-control" placeholder="Name">
					<div class="invalid-feedback">Enter your Name.</div>
				</div>
				<div class="input-group mb-3">
					<span class="input-group-text"><i class="fa-solid fa-phone"></i>
					</span> <input required="required" type="text" name="number"
						class="form-control" placeholder="Phone no.">
					<div class="invalid-feedback">Enter your Number</div>
				</div>
				<div class="input-group mb-3">
					<span class="input-group-text"><i class="fa-solid fa-city"></i></i>
					</span> <input required="required" type="" name="city"
						class="form-control" placeholder="City">
					<div class="invalid-feedback">Enter your City</div>
				</div>
				<div class="input-group mb-3">
					<span class="input-group-text"><i class="fa-solid fa-file"></i>
					</span> <input required="required" type="file" name="profile"
						class="form-control" placeholder="Profile Pic">
					<div class="invalid-feedback">Choose your Profile Pic</div>
				</div>
				<br>
				<div class="text-center">
					<button class="btn btn-danger">
						<i class="fa-solid fa-lock"></i> Submit
					</button>
				</div>
			</form>
		</div>
	</div>
	<%@include file="/common/footer.jsp"%>
	<script src="/InfiniteRunner/javascript/validation.js"></script>
	<script
		src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"
		integrity="sha384-ndDqU0Gzau9qJ1lfW4pNLlhNTkCfHzAVBReH9diLvGRem5+R9g2FzA8ZGN954O5Q"
		crossorigin="anonymous"></script>
</body>
</html>