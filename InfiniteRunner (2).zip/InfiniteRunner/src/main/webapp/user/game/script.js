class InfiniteRunner {
    constructor() {
        this.canvas = document.getElementById('gameCanvas');
        this.ctx = this.canvas.getContext('2d');
        this.mainMenu = document.getElementById('mainMenu');
        this.gameOverMenu = document.getElementById('gameOverMenu');
        this.pauseMenu = document.getElementById('pauseMenu');
        this.hud = document.getElementById('hud');
        
        this.gameState = 'menu'; // menu, playing, paused, gameOver
        this.difficulty = 'easy';
        this.score = 0;
        this.distance = 0;
        this.lives = 3;
        this.gameSpeed = 5;
        this.gravity = 0.8;
        this.jumpPower = -15;
        
        this.player = {
            x: 100,
            y: this.canvas.height - 100,
            width: 50,
            height: 70,
            velocityY: 0,
            isJumping: false,
            color: '#FF6B6B',
            image: null,
            imageLoaded: false,
            animationFrame: 0
        };
        
        this.obstacles = [];
        this.coins = [];
        this.hearts = [];
        this.particles = [];
        this.backgroundLayers = [];
        this.stars = [];
        
        this.keys = {};
        this.lastTime = 0;
        this.obstacleTimer = 0;
        this.coinTimer = 0;
        this.heartTimer = 0;
        this.particleTimer = 0;
        
        this.difficultySettings = {
            easy: {
                obstacleSpawnRate: 300,
                coinSpawnRate: 150,
                heartSpawnRate: 2000,
                gameSpeed: 5,
                obstacleSpeed: 5,
                lives: 3
            },
            medium: {
                obstacleSpawnRate: 250,
                coinSpawnRate: 120,
                heartSpawnRate: 1800,
                gameSpeed: 7,
                obstacleSpeed: 7,
                lives: 2
            },
            hard: {
                obstacleSpawnRate: 200,
                coinSpawnRate: 100,
                heartSpawnRate: 1500,
                gameSpeed: 9,
                obstacleSpeed: 9,
                lives: 1
            }
        };
        
        this.init();
    }
    
    init() {
        this.setupCanvas();
        this.setupEventListeners();
        this.createBackgroundLayers();
        this.createStars();
        this.loadPlayerImage();
        this.showMainMenu();
    }
    
    setupCanvas() {
        this.canvas.width = window.innerWidth;
        this.canvas.height = window.innerHeight;
        
        window.addEventListener('resize', () => {
            this.canvas.width = window.innerWidth;
            this.canvas.height = window.innerHeight;
            this.player.y = this.canvas.height - 100;
        });
    }
    
    setupEventListeners() {
        // Difficulty buttons
        document.querySelectorAll('.difficulty-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.difficulty = e.target.dataset.difficulty;
                this.startGame();
            });
        });
        
        // Game buttons
        document.getElementById('restartBtn').addEventListener('click', () => this.startGame());
        document.getElementById('mainMenuBtn').addEventListener('click', () => this.showMainMenu());
        document.getElementById('resumeBtn').addEventListener('click', () => this.resumeGame());
        document.getElementById('quitBtn').addEventListener('click', () => this.showMainMenu());
        
        // Keyboard controls
        document.addEventListener('keydown', (e) => {
            this.keys[e.code] = true;
            
            if (e.code === 'Space' && this.gameState === 'playing') {
                e.preventDefault();
                this.jump();
            }
            
            if (e.code === 'Escape') {
                if (this.gameState === 'playing') {
                    this.pauseGame();
                } else if (this.gameState === 'paused') {
                    this.resumeGame();
                }
            }
        });
        
        document.addEventListener('keyup', (e) => {
            this.keys[e.code] = false;
        });
    }
    
    createBackgroundLayers() {
        // Create multiple background layers for parallax effect
        for (let i = 0; i < 5; i++) {
            this.backgroundLayers.push({
                x: 0,
                y: i * 100,
                width: this.canvas.width,
                height: 100,
                speed: (i + 1) * 0.5,
                color: `hsl(${200 + i * 20}, 70%, ${60 - i * 10}%)`
            });
        }
    }
    
    createStars() {
        // Create stars for night sky
        for (let i = 0; i < 100; i++) {
            this.stars.push({
                x: Math.random() * this.canvas.width,
                y: Math.random() * (this.canvas.height - 200),
                size: Math.random() * 3 + 1,
                brightness: Math.random(),
                twinkleSpeed: Math.random() * 0.02 + 0.01,
                twinklePhase: Math.random() * Math.PI * 2
            });
        }
    }
    
    loadPlayerImage() {
        this.player.image = new Image();
        this.player.image.onload = () => {
            this.player.imageLoaded = true;
        };
        this.player.image.onerror = () => {
            console.log('Player image failed to load, using default character');
            this.player.imageLoaded = false;
        };
        // Using our custom animated SVG character
        this.player.image.src = 'player-character.svg';
    }
    
    showMainMenu() {
        this.gameState = 'menu';
        this.mainMenu.classList.remove('hidden');
        this.gameOverMenu.classList.add('hidden');
        this.pauseMenu.classList.add('hidden');
        this.canvas.classList.add('hidden');
        this.hud.classList.add('hidden');
    }
    
    startGame() {
        this.gameState = 'playing';
        this.score = 0;
        this.distance = 0;
        this.lives = this.difficultySettings[this.difficulty].lives;
        this.gameSpeed = this.difficultySettings[this.difficulty].gameSpeed;
        
        this.player.y = this.canvas.height - 100;
        this.player.velocityY = 0;
        this.player.isJumping = false;
        
        this.obstacles = [];
        this.coins = [];
        this.hearts = [];
        this.particles = [];
        this.stars = [];
        this.createStars();
        
        this.mainMenu.classList.add('hidden');
        this.gameOverMenu.classList.add('hidden');
        this.pauseMenu.classList.add('hidden');
        this.canvas.classList.remove('hidden');
        this.hud.classList.remove('hidden');
        
        this.updateHUD();
        this.gameLoop();
    }
    
    pauseGame() {
        this.gameState = 'paused';
        this.pauseMenu.classList.remove('hidden');
    }
    
    resumeGame() {
        this.gameState = 'playing';
        this.pauseMenu.classList.add('hidden');
        this.gameLoop();
    }
    
    gameOver() {
        this.gameState = 'gameOver';
        document.getElementById('finalScore').textContent = this.score;
        document.getElementById('finalDistance').textContent = Math.floor(this.distance);
        this.gameOverMenu.classList.remove('hidden');
        this.canvas.classList.add('hidden');
        this.hud.classList.add('hidden');
    }
    
    jump() {
        if (!this.player.isJumping) {
            this.player.velocityY = this.jumpPower;
            this.player.isJumping = true;
            this.createParticles(this.player.x + this.player.width / 2, this.player.y + this.player.height, 10);
        }
    }
    
    createParticles(x, y, count) {
        for (let i = 0; i < count; i++) {
            this.particles.push({
                x: x + (Math.random() - 0.5) * 20,
                y: y,
                vx: (Math.random() - 0.5) * 4,
                vy: -Math.random() * 3 - 1,
                life: 1,
                decay: 0.02
            });
        }
    }
    
    updateParticles() {
        for (let i = this.particles.length - 1; i >= 0; i--) {
            const particle = this.particles[i];
            particle.x += particle.vx;
            particle.y += particle.vy;
            particle.vy += 0.1;
            particle.life -= particle.decay;
            
            if (particle.life <= 0) {
                this.particles.splice(i, 1);
            }
        }
    }
    
    spawnObstacle() {
        // Check if there's enough space between obstacles
        if (this.obstacles.length > 0) {
            const lastObstacle = this.obstacles[this.obstacles.length - 1];
            const minDistance = 200; // Minimum distance between obstacles
            
            if (this.canvas.width - lastObstacle.x < minDistance) {
                return; // Don't spawn if too close
            }
        }
        
        const types = ['rock', 'tree', 'spike'];
        const type = types[Math.floor(Math.random() * types.length)];
        
        let obstacle = {
            x: this.canvas.width,
            y: this.canvas.height - 80,
            width: 30,
            height: 60,
            type: type,
            color: '#8B4513'
        };
        
        if (type === 'spike') {
            obstacle.height = 40;
            obstacle.y = this.canvas.height - 40;
            obstacle.color = '#FF4444';
        }
        
        this.obstacles.push(obstacle);
    }
    
    spawnCoin() {
        // Check if there's enough space from obstacles
        if (this.obstacles.length > 0) {
            const lastObstacle = this.obstacles[this.obstacles.length - 1];
            const minDistance = 100; // Minimum distance from obstacles
            
            if (this.canvas.width - lastObstacle.x < minDistance) {
                return; // Don't spawn if too close to obstacles
            }
        }
        
        this.coins.push({
            x: this.canvas.width,
            y: this.canvas.height - 150 + Math.random() * 100,
            width: 20,
            height: 20,
            collected: false,
            animation: 0
        });
    }
    
    spawnHeart() {
        // Check if there's enough space from obstacles
        if (this.obstacles.length > 0) {
            const lastObstacle = this.obstacles[this.obstacles.length - 1];
            const minDistance = 150; // Minimum distance from obstacles
            
            if (this.canvas.width - lastObstacle.x < minDistance) {
                return; // Don't spawn if too close to obstacles
            }
        }
        
        this.hearts.push({
            x: this.canvas.width,
            y: this.canvas.height - 150 + Math.random() * 100,
            width: 25,
            height: 25,
            collected: false,
            animation: 0
        });
    }
    
    updatePlayer() {
        // Apply gravity
        this.player.velocityY += this.gravity;
        this.player.y += this.player.velocityY;
        
        // Update animation frame
        this.player.animationFrame += 0.1;
        
        // Ground collision
        if (this.player.y > this.canvas.height - 100) {
            this.player.y = this.canvas.height - 100;
            this.player.velocityY = 0;
            this.player.isJumping = false;
        }
        
        // Ceiling collision
        if (this.player.y < 0) {
            this.player.y = 0;
            this.player.velocityY = 0;
        }
    }
    
    updateObstacles() {
        for (let i = this.obstacles.length - 1; i >= 0; i--) {
            const obstacle = this.obstacles[i];
            obstacle.x -= this.difficultySettings[this.difficulty].obstacleSpeed;
            
            // Remove off-screen obstacles
            if (obstacle.x + obstacle.width < 0) {
                this.obstacles.splice(i, 1);
                continue;
            }
            
            // Regular collision detection (side collision)
            if (this.checkCollision(this.player, obstacle)) {
                this.lives--;
                this.updateHUD();
                this.createParticles(this.player.x + this.player.width / 2, this.player.y + this.player.height / 2, 20);
                
                if (this.lives <= 0) {
                    this.gameOver();
                    return;
                }
                
                // Remove the obstacle that was hit
                this.obstacles.splice(i, 1);
            }
        }
    }
    
    updateCoins() {
        for (let i = this.coins.length - 1; i >= 0; i--) {
            const coin = this.coins[i];
            coin.x -= this.difficultySettings[this.difficulty].obstacleSpeed;
            coin.animation += 0.1;
            
            // Remove off-screen coins
            if (coin.x + coin.width < 0) {
                this.coins.splice(i, 1);
                continue;
            }
            
            // Collision detection
            if (!coin.collected && this.checkCollision(this.player, coin)) {
                coin.collected = true;
                this.score += 10;
                this.updateHUD();
                this.createParticles(coin.x + coin.width / 2, coin.y + coin.height / 2, 15);
                this.coins.splice(i, 1);
            }
        }
    }
    
    updateHearts() {
        for (let i = this.hearts.length - 1; i >= 0; i--) {
            const heart = this.hearts[i];
            heart.x -= this.difficultySettings[this.difficulty].obstacleSpeed;
            heart.animation += 0.1;
            
            // Remove off-screen hearts
            if (heart.x + heart.width < 0) {
                this.hearts.splice(i, 1);
                continue;
            }
            
            // Collision detection
            if (!heart.collected && this.checkCollision(this.player, heart)) {
                heart.collected = true;
                if (this.lives < 5) { // Maximum 5 lives
                    this.lives++;
                }
                this.updateHUD();
                this.createParticles(heart.x + heart.width / 2, heart.y + heart.height / 2, 20);
                this.hearts.splice(i, 1);
            }
        }
    }
    
    checkCollision(rect1, rect2) {
        return rect1.x < rect2.x + rect2.width &&
               rect1.x + rect1.width > rect2.x &&
               rect1.y < rect2.y + rect2.height &&
               rect1.y + rect1.height > rect2.y;
    }
    
    updateBackground() {
        this.backgroundLayers.forEach(layer => {
            layer.x -= layer.speed;
            if (layer.x <= -this.canvas.width) {
                layer.x = 0;
            }
        });
    }
    
    updateStars() {
        this.stars.forEach(star => {
            star.twinklePhase += star.twinkleSpeed;
            star.brightness = 0.3 + 0.7 * Math.sin(star.twinklePhase);
        });
    }
    
    updateHUD() {
        document.getElementById('score').textContent = this.score;
        document.getElementById('distance').textContent = Math.floor(this.distance);
        document.getElementById('lives').textContent = this.lives;
    }
    
    drawBackground() {
        // Night sky gradient
        const gradient = this.ctx.createLinearGradient(0, 0, 0, this.canvas.height);
        gradient.addColorStop(0, '#0B1426');
        gradient.addColorStop(0.3, '#1a1a2e');
        gradient.addColorStop(0.7, '#16213e');
        gradient.addColorStop(1, '#0f3460');
        
        this.ctx.fillStyle = gradient;
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Draw stars
        this.stars.forEach(star => {
            this.ctx.save();
            this.ctx.globalAlpha = star.brightness;
            this.ctx.fillStyle = '#FFFFFF';
            this.ctx.beginPath();
            this.ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2);
            this.ctx.fill();
            
            // Add star glow effect
            if (star.brightness > 0.8) {
                this.ctx.globalAlpha = star.brightness * 0.3;
                this.ctx.beginPath();
                this.ctx.arc(star.x, star.y, star.size * 2, 0, Math.PI * 2);
                this.ctx.fill();
            }
            this.ctx.restore();
        });
        
        // Animated background layers (darker for night)
        this.backgroundLayers.forEach(layer => {
            this.ctx.fillStyle = `rgba(26, 26, 46, 0.3)`;
            this.ctx.fillRect(layer.x, layer.y, layer.width, layer.height);
            this.ctx.fillRect(layer.x + layer.width, layer.y, layer.width, layer.height);
        });
        
        // Ground (darker for night)
        this.ctx.fillStyle = '#2d1810';
        this.ctx.fillRect(0, this.canvas.height - 40, this.canvas.width, 40);
    }
    
    drawPlayer() {
        // Player shadow
        this.ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
        this.ctx.fillRect(this.player.x + 5, this.canvas.height - 35, this.player.width - 10, 10);
        
        if (this.player.imageLoaded && this.player.image) {
            // Draw player image
            this.ctx.drawImage(
                this.player.image, 
                this.player.x, 
                this.player.y, 
                this.player.width, 
                this.player.height
            );
            
            // Add glow effect when jumping
            if (this.player.isJumping) {
                this.ctx.save();
                this.ctx.globalAlpha = 0.3;
                this.ctx.shadowColor = '#FFD700';
                this.ctx.shadowBlur = 10;
                this.ctx.drawImage(
                    this.player.image, 
                    this.player.x, 
                    this.player.y, 
                    this.player.width, 
                    this.player.height
                );
                this.ctx.restore();
            }
        } else {
            // Fallback to original rectangle character
            this.ctx.fillStyle = this.player.color;
            this.ctx.fillRect(this.player.x, this.player.y, this.player.width, this.player.height);
            
            // Player details
            this.ctx.fillStyle = '#FFD700';
            this.ctx.fillRect(this.player.x + 5, this.player.y + 5, 10, 10); // Eye
            this.ctx.fillRect(this.player.x + 25, this.player.y + 5, 10, 10); // Eye
            
            // Jump animation
            if (this.player.isJumping) {
                this.ctx.fillStyle = 'rgba(255, 255, 255, 0.5)';
                this.ctx.fillRect(this.player.x - 5, this.player.y + this.player.height - 10, this.player.width + 10, 5);
            }
        }
    }
    
    drawObstacles() {
        this.obstacles.forEach(obstacle => {
            this.ctx.fillStyle = obstacle.color;
            
            if (obstacle.type === 'spike') {
                // Draw triangle spike
                this.ctx.beginPath();
                this.ctx.moveTo(obstacle.x + obstacle.width / 2, obstacle.y);
                this.ctx.lineTo(obstacle.x, obstacle.y + obstacle.height);
                this.ctx.lineTo(obstacle.x + obstacle.width, obstacle.y + obstacle.height);
                this.ctx.closePath();
                this.ctx.fill();
            } else {
                this.ctx.fillRect(obstacle.x, obstacle.y, obstacle.width, obstacle.height);
            }
        });
    }
    
    drawCoins() {
        this.coins.forEach(coin => {
            this.ctx.save();
            this.ctx.translate(coin.x + coin.width / 2, coin.y + coin.height / 2);
            this.ctx.rotate(coin.animation);
            
            this.ctx.fillStyle = '#FFD700';
            this.ctx.beginPath();
            this.ctx.arc(0, 0, coin.width / 2, 0, Math.PI * 2);
            this.ctx.fill();
            
            this.ctx.fillStyle = '#FFA500';
            this.ctx.beginPath();
            this.ctx.arc(0, 0, coin.width / 3, 0, Math.PI * 2);
            this.ctx.fill();
            
            this.ctx.restore();
        });
    }
    
    drawHearts() {
        this.hearts.forEach(heart => {
            this.ctx.save();
            this.ctx.translate(heart.x + heart.width / 2, heart.y + heart.height / 2);
            this.ctx.scale(0.8 + 0.2 * Math.sin(heart.animation), 0.8 + 0.2 * Math.sin(heart.animation));
            
            // Draw heart shape
            this.ctx.fillStyle = '#FF69B4';
            this.ctx.beginPath();
            this.ctx.moveTo(0, -heart.height / 3);
            this.ctx.bezierCurveTo(-heart.width / 2, -heart.height / 2, -heart.width / 2, heart.height / 4, 0, heart.height / 2);
            this.ctx.bezierCurveTo(heart.width / 2, heart.height / 4, heart.width / 2, -heart.height / 2, 0, -heart.height / 3);
            this.ctx.fill();
            
            // Add glow effect
            this.ctx.shadowColor = '#FF1493';
            this.ctx.shadowBlur = 10;
            this.ctx.fill();
            
            this.ctx.restore();
        });
    }
    
    drawParticles() {
        this.particles.forEach(particle => {
            this.ctx.save();
            this.ctx.globalAlpha = particle.life;
            this.ctx.fillStyle = '#FFD700';
            this.ctx.beginPath();
            this.ctx.arc(particle.x, particle.y, 3, 0, Math.PI * 2);
            this.ctx.fill();
            this.ctx.restore();
        });
    }
    
    gameLoop(currentTime = 0) {
        if (this.gameState !== 'playing') return;
        
        const deltaTime = currentTime - this.lastTime;
        this.lastTime = currentTime;
        
        // Update game state
        this.updatePlayer();
        this.updateObstacles();
        this.updateCoins();
        this.updateHearts();
        this.updateParticles();
        this.updateBackground();
        this.updateStars();
        
        // Spawn obstacles, coins, and hearts
        this.obstacleTimer += deltaTime;
        this.coinTimer += deltaTime;
        this.heartTimer += deltaTime;
        
        if (this.obstacleTimer > this.difficultySettings[this.difficulty].obstacleSpawnRate) {
            this.spawnObstacle();
            this.obstacleTimer = 0;
        }
        
        if (this.coinTimer > this.difficultySettings[this.difficulty].coinSpawnRate) {
            this.spawnCoin();
            this.coinTimer = 0;
        }
        
        if (this.heartTimer > this.difficultySettings[this.difficulty].heartSpawnRate) {
            this.spawnHeart();
            this.heartTimer = 0;
        }
        
        // Update distance and score
        this.distance += this.gameSpeed * 0.01;
        this.score += Math.floor(this.gameSpeed * 0.1);
        this.updateHUD();
        
        // Clear canvas
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Draw everything
        this.drawBackground();
        this.drawObstacles();
        this.drawCoins();
        this.drawHearts();
        this.drawPlayer();
        this.drawParticles();
        
        // Continue game loop
        requestAnimationFrame((time) => this.gameLoop(time));
    }
}

// Initialize the game when the page loads
window.addEventListener('load', () => {
    new InfiniteRunner();
}); 