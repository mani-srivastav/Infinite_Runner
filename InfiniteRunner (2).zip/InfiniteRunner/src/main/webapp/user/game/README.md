# Infinite Runner Game

A modern, responsive infinite runner game built with HTML5 Canvas, CSS3, and JavaScript. Features different difficulty levels and animated background effects that create a 3D-like gaming experience.

## Features

### 🎮 Gameplay
- **Infinite Runner**: Endless gameplay with increasing difficulty
- **Multiple Difficulty Levels**: Easy, Medium, and Hard modes
- **Jump Mechanics**: Press SPACE to jump and avoid obstacles
- **Coin Collection**: Collect coins to increase your score
- **Lives System**: Different number of lives based on difficulty
- **Distance Tracking**: See how far you've run

### 🎨 Visual Effects
- **Animated Background**: Parallax scrolling background with gradient effects
- **Particle Effects**: Visual feedback when jumping and collecting items
- **3D-like Appearance**: Layered backgrounds and depth effects
- **Modern UI**: Glassmorphism design with blur effects
- **Responsive Design**: Works on desktop and mobile devices

### 🎯 Difficulty Levels

#### Easy Mode
- 3 lives
- Slower obstacle spawn rate
- More coins to collect
- Lower game speed

#### Medium Mode
- 2 lives
- Moderate obstacle spawn rate
- Balanced gameplay
- Medium game speed

#### Hard Mode
- 1 life
- Fast obstacle spawn rate
- Fewer coins
- High game speed

## How to Play

1. **Start the Game**: Open `index.html` in a modern web browser
2. **Choose Difficulty**: Select Easy, Medium, or Hard from the main menu
3. **Controls**:
   - **SPACE**: Jump
   - **ESC**: Pause/Resume game
4. **Objective**: Avoid obstacles (rocks, trees, spikes) and collect coins
5. **Scoring**: Earn points by running distance and collecting coins
6. **Game Over**: When you lose all lives, your final score is displayed

## Game Elements

### Player Character
- Red rectangular character with golden eyes
- Can jump to avoid obstacles
- Leaves particle effects when jumping

### Obstacles
- **Rocks**: Basic rectangular obstacles
- **Trees**: Taller obstacles
- **Spikes**: Triangular obstacles (red color)

### Collectibles
- **Coins**: Golden circular coins that rotate
- **Particle Effects**: Visual feedback when collected

### Background
- **Sky Gradient**: Blue to green to orange gradient
- **Parallax Layers**: Multiple scrolling background layers
- **Ground**: Brown ground at the bottom

## Technical Features

### Performance Optimizations
- Efficient collision detection
- Object pooling for particles
- Optimized rendering with requestAnimationFrame
- Responsive canvas sizing

### Browser Compatibility
- Modern browsers with HTML5 Canvas support
- CSS3 features for visual effects
- ES6+ JavaScript features

## File Structure

```
runner-game/
├── index.html      # Main HTML file
├── style.css       # CSS styles and animations
├── script.js       # Game logic and mechanics
└── README.md       # This file
```

## Customization

You can easily customize the game by modifying:

- **Colors**: Change player, obstacle, and background colors in the CSS
- **Speeds**: Adjust game speeds in the difficulty settings
- **Spawn Rates**: Modify obstacle and coin spawn frequencies
- **Visual Effects**: Add new particle effects or animations
- **Sound**: Add audio effects for jumping, collecting, and game over

## Future Enhancements

- Sound effects and background music
- Power-ups and special abilities
- Multiple character skins
- Leaderboard system
- Mobile touch controls
- More obstacle types
- Background themes

## Credits

Created with HTML5 Canvas, CSS3, and vanilla JavaScript. No external libraries required!

Enjoy playing! 🎮 