<%@ page language="java" contentType="text/html; charset=UTF-8"
	pageEncoding="UTF-8"%>

<%@page import="java.util.*"%>
<%@page import="runner.beans.*"%>
<%@page import="runner.dao.*"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Infinite Runner</title>
</head>
<%@include file="/common/common_css.html"%>
<body style="background-image: url(/InfiniteRunner/images/GameBackground.jpeg); background-repeat: no-repeat; background-size: cover">
	<%
	String adminEmail = (String) session.getAttribute("sessionKey");
	String adminRole = (String) session.getAttribute("role");
	if (adminEmail != null && adminRole.equals("admin")) {
		
		AdminDao dao=new AdminDao();
		ArrayList<FeedBack>feedbackList=dao.allFeedBacks();
		int size=feedbackList.size();//it returns the length of ArrayList
	%>
	<%@include file="/admin/admin_header.html"%>
	<div class="main-div">
		<div class="container-fluid"
			style=" margin-top: 70px">
			<h2 style="text-align: center;color: white;font-style: italic;">FeedBack Details</h2>
		</div>
		<div style="margin: auto">
		<%if(size>0){ %>
			<table class="table">
				<thead>
					<tr> <!-- id, email, name, review, rating, date -->
						<th scope="col">SerialNumber</th>
						<th scope="col">Email</th>
						<th scope="col">Name</th>
						<th scope="col">Review</th>
						<th scope="col">Rating</th>
						<th scope="col">Date</th>
					</tr>
				</thead>
				<tbody>
				<%
				for(FeedBack f:feedbackList)
				{
				%>
				<tr>
				<td scope="row"><%=f.getId() %></td>
				<td scope="row"><%=f.getEmail() %></td>
				<td scope="row"><%=f.getName() %></td>
				<td scope="row"><%=f.getRating() %></td>
				<td scope="row"><%=f.getReview() %></td>
				<td scope="row"><%=f.getDate() %></td>
				</tr>
				<%} %>
				</tbody>
			</table>
			<%
			} 
			else{
			
			%>
			<h2 style="text-align: center;">No Contacts Available</h2>
			<%} %>
		</div>


	</div>
	<%@include file="/common/footer.jsp"%>


	<%
	} else {
	request.setAttribute("message", "UnAuthorized Access");
	RequestDispatcher rd = request.getRequestDispatcher("/admin/admin_login.jsp");
	rd.forward(request, response);
	}
	%>
	<script
		src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"
		integrity="sha384-ndDqU0Gzau9qJ1lfW4pNLlhNTkCfHzAVBReH9diLvGRem5+R9g2FzA8ZGN954O5Q"
		crossorigin="anonymous"></script>

</body>
</html>