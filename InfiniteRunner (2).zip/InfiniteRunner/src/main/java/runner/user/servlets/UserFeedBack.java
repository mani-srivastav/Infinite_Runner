package runner.user.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import runner.beans.FeedBack;
import runner.dao.UserDao;


@WebServlet("/UserFeedBack")
public class UserFeedBack extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public UserFeedBack() {
        super();

    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userEmail=request.getParameter("email");
		String userName=request.getParameter("name");
		String userReview=request.getParameter("remarks");
		String userRating=request.getParameter("rating");
		
		java.util.Date d=new java.util.Date();
		System.out.println("date is"+d);
		
		long dt=d.getTime();
		java.sql.Date sd=new java.sql.Date(dt);
		System.out.println("sql date "+sd);
		
		FeedBack f=new FeedBack(userEmail,userName,userReview,userRating,sd);
		UserDao dao=new UserDao();
		
		int status=dao.addFeedBack(f);
		if(status>0)
		{
			request.setAttribute("message", "Thankyou for your feedback 🙌🙌");

			RequestDispatcher rd=request.getRequestDispatcher("/user/user_feedback.jsp");
			
			rd.forward(request, response);
		}

	}

}
