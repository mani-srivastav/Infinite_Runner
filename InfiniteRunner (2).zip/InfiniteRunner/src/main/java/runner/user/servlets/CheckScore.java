package runner.user.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import runner.dao.UserDao;

/**
 * Servlet implementation class CheckScore
 */
@WebServlet("/CheckScore")
public class CheckScore extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CheckScore() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String score=request.getParameter("score");	
		String distance=request.getParameter("distance");	
		System.out.println(score+"  "+distance);
		PrintWriter out=response.getWriter();
		//out.write("Hello servlet");
		
		HttpSession hs=request.getSession(false);
		
		
		String email=(String)hs.getAttribute("sessionKey");
		
		
		UserDao dao=new UserDao();
		
		
		int status=	dao.updateScore(score,distance,email);
		if(status>0)
			out.print("High Score");
		else
			out.print("Score");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
