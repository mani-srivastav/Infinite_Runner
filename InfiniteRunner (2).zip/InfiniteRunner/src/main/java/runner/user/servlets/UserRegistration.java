package runner.user.servlets;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import runner.beans.UserDetails;
import runner.dao.UserDao;

@MultipartConfig
@WebServlet("/UserRegistration")
public class UserRegistration extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public UserRegistration() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();//with the help of pw we can print data on the browser
		String emailId=request.getParameter("uEmail");
		System.out.println("email id is "+emailId);
		UserDao dao=new UserDao();
		boolean status= dao.checkEmail(emailId);
		if(status==true) {
			pw.print(status);
		}	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userEmail=request.getParameter("email");
		String userPass=request.getParameter("password");
		String userName=request.getParameter("name"); 
		String userPhone=request.getParameter("number");
		String userCity=request.getParameter("city");
		String userPic=request.getParameter("profile");
		
		Part p=request.getPart("profile");
		String imageName=p.getSubmittedFileName();
		System.out.println("image name is "+imageName);
		
		//to find the path of the server where the website is getting hosted
		ServletContext sc=getServletContext();//creating object of ServletContext
		String serverPath=sc.getRealPath("");
		System.out.println("server path is "+serverPath);
		String folderName="userPic";
		String fullPath=serverPath+folderName;
		File f=new File(fullPath);
		
		if(f.exists()==false) 
		{
			f.mkdir();//it will create the folder of userPicName
			System.out.println("Folder created");
		}
		String DBPath=folderName+File.separator+imageName;
		//uploading image into userPic folder
		
		String imagePathForServer=fullPath+File.separator+imageName;
		p.write(imagePathForServer);
		System.out.println("image uploaded on server");
		//image uploading code ends
		
		//user registration code for database
		
		UserDetails user=new UserDetails(userEmail,userPass,userName,userPhone,userCity,DBPath);				
				UserDao dao=new UserDao();
		int status=dao.registerUser(user);
		
		if (status>0) {
			response.sendRedirect("/InfiniteRunner/user/user_login.jsp");
		}
	}

}