package runner.user.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import runner.dao.UserDao;


@WebServlet("/UserLogin")
public class UserLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public UserLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userEmail=request.getParameter("email");
		String userPass=request.getParameter("password");
		
		
		System.out.println("user email is "+userEmail);
		System.out.println("user password is "+userPass);
		
		//no need of bean class object as there is less data
		
	    UserDao dao=new UserDao();
	    boolean loginStatus=dao.userLogin(userEmail,userPass);
	    if(loginStatus) 
	    {
	    	HttpSession hs=request.getSession();//it will create a session
	    	hs.setAttribute("sessionKey", userEmail);
	    	hs.setAttribute("role", "user");
	    	response.sendRedirect("/InfiniteRunner/user/user_home.jsp"); //with this we can move to another page after login
	    }
	    else {
	    	request.setAttribute("message","Invalid Credentials");
            RequestDispatcher rd=request.getRequestDispatcher("/user/user_login.jsp");
			rd.forward(request, response);
	    }
	}

}
