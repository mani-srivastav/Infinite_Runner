package runner.beans;

public class GameScore {
	
private String email;
private int score,distance;


public GameScore() {
	super();
	// TODO Auto-generated constructor stub
}

public GameScore(int score, int distance) {
	super();
	this.score = score;
	this.distance = distance;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

public int getScore() {
	return score;
}

public void setScore(int score) {
	this.score = score;
}

public int getDistance() {
	return distance;
}

public void setDistance(int distance) {
	this.distance = distance;
}

}
