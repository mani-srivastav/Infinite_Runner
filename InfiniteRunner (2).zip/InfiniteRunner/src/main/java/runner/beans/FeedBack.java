package runner.beans;

import java.sql.Date;

public class FeedBack {
	private UserDetails user;// HAS-A-Relationship
	public UserDetails getUser() {
		return user;
	}


	public void setUser(UserDetails user) {
		this.user = user;
	}
	
	
	private int id; 
	private String email, name, rating, review;
	private Date date;
	
	public FeedBack() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public FeedBack(String email, String name, String rating, String review, Date date) {
		super();
		this.email = email;
		this.name = name;
		this.rating = rating;
		this.review = review;
		this.date = date;
	}


	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public String getReview() {
		return review;
	}
	public void setReview(String review) {
		this.review = review;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	
	

}
