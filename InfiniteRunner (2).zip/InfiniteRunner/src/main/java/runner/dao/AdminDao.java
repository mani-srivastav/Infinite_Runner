package runner.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import runner.beans.Contact;
import runner.beans.FeedBack;
import runner.beans.UserDetails;
import runner.dbutils.DBConnection;

public class AdminDao {
//------method 1 to view contact------
	public ArrayList<Contact> allContacts() {
		ArrayList<Contact> contactList = new ArrayList<Contact>();
		Connection con = DBConnection.openConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		Contact contact = null;
		String selectQuery = "select * from contact order by date desc";
		try {
			ps = con.prepareStatement(selectQuery);
			rs = ps.executeQuery();
			/* id, name, email, phone, question, date */
			// fetching data from table
			while (rs.next()) {
				String name = rs.getString("name");
				String email = rs.getString("email");
				String phone = rs.getString("phone");
				String question = rs.getString("question");
				Date date = rs.getDate("date");
				int id = rs.getInt("id");
				// creating object of contact bean
				contact = new Contact(name, email, phone, question, date);
				contact.setId(id);
				// adding object into ArrayList
				contactList.add(contact);

			}
		} catch (SQLException se) {
			se.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}
		return contactList;// returning ArrayList to jsp page to the caller
	}

//-----method 2 to view feedback-----	
	public ArrayList<FeedBack> allFeedBacks() {
		ArrayList<FeedBack> feedbackList = new ArrayList<FeedBack>();
		Connection con = DBConnection.openConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		FeedBack feedback = null;
		String selectQuery = "select * from feedback order by date desc";
		try {
			ps = con.prepareStatement(selectQuery);
			rs = ps.executeQuery();
			/* id, email, name, review, rating, date */
			// fetching data from table
			while (rs.next()) {
				String name = rs.getString("name");
				String email = rs.getString("email");
				String review = rs.getString("review");
				String rating = rs.getString("rating");
				Date date = rs.getDate("date");
				int id = rs.getInt("id");
				// creating object of contact bean
				feedback = new FeedBack(email, name, review, rating, date);
				feedback.setId(id);
				// adding object into ArrayList
				feedbackList.add(feedback);

			}
		} catch (SQLException se) {
			se.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}
		return feedbackList;
	}

//-----method 3 to view users-----	
	public ArrayList<UserDetails> allUsers() {
		ArrayList<UserDetails> userList = new ArrayList<UserDetails>();
		Connection con = DBConnection.openConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		UserDetails user = null;
		String selectQuery = "select * from user_details";
		try {
			ps = con.prepareStatement(selectQuery);
			rs = ps.executeQuery();
			/* email, password, name, phone, city, profile_pic */

			while (rs.next()) {
				String email = rs.getString("email");
				String password = rs.getString("password");
				String name = rs.getString("name");
				String phone = rs.getString("phone");
				String city = rs.getString("city");
				String pic = rs.getString("profile_pic");

				user = new UserDetails(email, password, name, phone, city, pic);

				userList.add(user);

			}
		} catch (SQLException se) {
			se.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}
		return userList;
	}
	//method 4 delete code 
		public int deleteContact(String[] array) {
			
			int status=0;
			Connection con = DBConnection.openConnection();
			PreparedStatement ps = null;
			
			String deleteQuery="delete from contact where id=?";
			try {
				ps = con.prepareStatement(deleteQuery);
	con.setAutoCommit(false);
				for(int i=0;i<array.length;i++)
				{
				
					int id=Integer.parseInt(array[i]);
					ps.setInt(1, id);
					//batch processing-> for huge amount of data we do batch processing 
					
					ps.addBatch();//it will temporary add data into buffer
					
				}
				
				int[] rowStatus=ps.executeBatch();
				int flag=0;
				for(int i=0;i<rowStatus.length;i++) {
					
					if(rowStatus[i]<0) {
						flag=1;
						break;
					}
				}
				
				 if(flag==0) {
					status=1;
					
					con.setAutoCommit(true); 
				}
			}
			catch (SQLException se) {
				se.printStackTrace();
			} 
			return status;
		}
	}

