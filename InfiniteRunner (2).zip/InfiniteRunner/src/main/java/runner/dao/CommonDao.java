package runner.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import runner.beans.Contact;
import runner.beans.FeedBack;
import runner.beans.UserDetails;
import runner.dbutils.DBConnection;

public class CommonDao { 
	public int addContact(Contact c) {
		int status = 0;

		// create connection with database
		Connection con = DBConnection.openConnection();
		String insertQuery = "insert into contact(name, email, phone, question, date) values(?,?,?,?,?)";

		PreparedStatement ps = null; // responsible to communicate with database table

		try {
			ps = con.prepareStatement(insertQuery);
			// it passes the query to mysql and compile the query and ps holds the address
			// of compiled query

			// code for inserting data into the table
			ps.setString(1, c.getName());
			ps.setString(2, c.getEmail());
			ps.setString(3, c.getPhone());
			ps.setString(4, c.getQuestion());
			ps.setDate(5, c.getDate());
			System.out.println(ps); // only for sql testing

			// method calling for executing insert query
			status = ps.executeUpdate();

		} catch (SQLException se) {
			se.printStackTrace();
		}
		return status;

	}

}
