package runner.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import runner.beans.FeedBack;
import runner.beans.GameScore;
import runner.beans.UserDetails;
import runner.dbutils.DBConnection;

public class UserDao {

	public int addFeedBack(FeedBack f) {
		int status = 0;

		Connection con = DBConnection.openConnection();
		String insertQuery = "insert into feedback(email, name, review, rating, date) values(?,?,?,?,?)";

		PreparedStatement ps = null;

		try {
			ps = con.prepareStatement(insertQuery);

			ps.setString(1, f.getEmail());
			ps.setString(2, f.getName());
			ps.setString(3, f.getRating());
			ps.setString(4, f.getReview());
			ps.setDate(5, f.getDate());

			status = ps.executeUpdate();

		} catch (SQLException se) {
			se.printStackTrace();
		}
		return status;
	}

	public int registerUser(UserDetails user) {
		int status = 0;

		Connection con = DBConnection.openConnection();
		String insertQuery = "insert into user_details(email, password, name, phone, city, profile_pic) values(?,?,?,?,?,?)";

		PreparedStatement ps = null;

		try {
			ps = con.prepareStatement(insertQuery);

			ps.setString(1, user.getEmail());
			ps.setString(2, user.getPassword());
			ps.setString(3, user.getName());
			ps.setString(4, user.getPhone());
			ps.setString(5, user.getCity());
			ps.setString(6, user.getProfile_pic());

			status = ps.executeUpdate();

		} catch (SQLException se) {
			se.printStackTrace();
		}

		return status;
	}

	// -------Method 3 for user login-------
	public boolean userLogin(String userEmail, String userPass) {

		Connection con = DBConnection.openConnection();
		String selectQuery = "select * from user_details where email=? and password=?";

		PreparedStatement ps = null;
		ResultSet rs = null; // it will hold the data returned by select query

		try {
			ps = con.prepareStatement(selectQuery);
			ps.setString(1, userEmail);
			ps.setString(2, userPass);
			System.out.println(ps);
			// code to sent this sql to database
			rs = ps.executeQuery();// rs will hold the reference of the rows returned by dbms
			if (rs.next() == true)// returns true if there will data
			{
				return true;
			}
		} catch (SQLException se) {
			se.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (ps != null)
					ps.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}

		return false;
	}
	public UserDetails userProfile(String userEmail) {
		Connection con = DBConnection.openConnection();
		String selectQuery="select * from user_details where email=?";
		PreparedStatement ps = null; // responsible to communicate with database table
		ResultSet rs=null;//it will hold data returned by select query
		
		UserDetails user=null;//creating reference of bean class
		try {
			ps=con.prepareStatement(selectQuery);
			ps.setString(1, userEmail);
			System.out.println(ps);
            rs=ps.executeQuery();
            rs.next();//to put the cursor in that row
			
            String userName=rs.getString("name");//read the column value
            String userPhone=rs.getString("phone");
            String userCity=rs.getString("city");
            String userPic=rs.getString("profile_pic");
            
            user=new UserDetails();//creating bean class object 
            
            user.setCity(userCity);
            user.setEmail(userEmail);
            user.setName(userName);
         user.setPhone(userPhone);
         user.setProfile_pic(userPic);
         
            
		}
		catch(SQLException se) {
			
			se.printStackTrace();
		}
		
		//finally code here
		finally {
			try {
				if(rs!=null)
					rs.close();	
				if(ps!=null)
					ps.close();		
				if(con!=null)
					con.close();		
			}
			
			catch(SQLException se) {
				
				se.printStackTrace();
			}
		}
		return user;
	}
	public int editProfile(UserDetails user)
	
	{
		Connection con = DBConnection.openConnection();
		PreparedStatement ps = null; // responsible to communicate with database table
String updateQuery="update user_details set city=?,phone=? where email=?";
int status=0;
try {
	ps=con.prepareStatement(updateQuery);
	ps.setString(1, user.getCity());
	ps.setString(2, user.getPhone());
	ps.setString(3, user.getEmail());
	System.out.println(ps);
	
	status=ps.executeUpdate();//insert,update/delete
	
}

catch(SQLException se) {
	
	se.printStackTrace();
}
		return status;
	}

	public int updateScore(String score, String distance, String email) {
		// TODO Auto-generated method stub
		
		//select * from score where email=?
		Connection con = DBConnection.openConnection();
		String selectQuery="select * from game_score where email=?";
		PreparedStatement ps = null; 
		PreparedStatement ps1 = null; 
		PreparedStatement ps2 = null; 
		PreparedStatement ps3 = null; 
		ResultSet rs=null;
		ResultSet rs1=null;
		int status=0;
		GameScore gscore=null;
		try {
			ps=con.prepareStatement(selectQuery);
			ps.setString(1, email);
			System.out.println(ps);
            rs=ps.executeQuery();
           if( rs.next())
           {
        	   String query="select score from game_score where email=?";
        	   ps2=con.prepareStatement(query);
        	   ps2.setString(1,email);
        	   rs1=ps2.executeQuery();
        	   rs1.next();
        	   int existingScore=rs1.getInt("score");
        	   if(Integer.parseInt(score)>existingScore)
        	   {
        		   
        		   String updateQuery="update game_score set score=?,distance=? where email=?";
        		   ps3=con.prepareStatement(updateQuery);
        		   ps3.setString(1, score);
        		   ps3.setString(2, distance);
        		   ps3.setString(3, email);
        		   
        		status=   ps3.executeUpdate();
        		   
        	   }
        	   
           }
           else {
        	   
        	   String insertQuery="insert into game_score(email,score,distance) values(?,?,?)";
        	   try {
        		   ps1 = con.prepareStatement(insertQuery);
        		   ps1.setString(1, email);
        		   ps1.setString(2, score);
        		   ps1.setString(3, distance);
        		   status=ps1.executeUpdate();
        		   
        	   }
        	   catch (SQLException se) {
				se.printStackTrace();
			}
           }
            
			
            
            
		}
		catch(SQLException se) {
			
			se.printStackTrace();
		}
		
		return status;
	}
    //-----AJAX email checking code-----
	public boolean checkEmail(String emailId) {
		
		Connection con=DBConnection.openConnection();
		
		PreparedStatement ps=null;
		ResultSet rs=null;
		String selectQuery="select email from user_details where email=?";
		
		try {
			ps=con.prepareStatement(selectQuery);
			ps.setString(1, emailId);
			System.out.println(ps);
			rs=ps.executeQuery();
			if(rs.next()) {
				return true;
			}
		}
		catch (SQLException se) {
			se.printStackTrace();
		}
		finally {
			try {
				if(rs!=null)
					rs.close();	
				if(ps!=null)
					ps.close();		
				if(con!=null)
					con.close();		
			}
			
			catch(SQLException se) {
				
				se.printStackTrace();
			}
		}
		return false;
	}
	
}
