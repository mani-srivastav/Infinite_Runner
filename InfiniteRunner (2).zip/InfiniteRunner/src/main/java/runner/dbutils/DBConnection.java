package runner.dbutils;
import java.sql.*;
import java.util.ResourceBundle;//to read data from properties file
public class DBConnection {

	private static Connection con;
	private static ResourceBundle rb;
	public static Connection openConnection() 
	{
		
		try {
			
			//Creating object of resource bundle with file reference
			rb=ResourceBundle.getBundle("runner/dbutils/db_info");
			String dbUser=rb.getString("app.dbUserId");
			String dbUserPass=rb.getString("app.dbUserPass");//reading data from properties file
			String dbUrl=rb.getString("app.dbUrl");
			System.out.println("user id "+dbUser);
			System.out.println(rb);
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			//con=DriverManager.getConnection("jdbc:mysql://localhost:3306/runner_db","root","root");
			con=DriverManager.getConnection(dbUrl,dbUser,dbUserPass);
		}
		catch(ClassNotFoundException |SQLException cse)
		{
			cse.printStackTrace();
		}
		return con;
	}

	/*
	 * public static void main(String[] args) { Connection con=openConnection();
	 * System.out.println(con); }
	 */
	 
}
