package runner.common.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import runner.beans.Contact;
import runner.dao.CommonDao;


@WebServlet("/ContactUs")
public class ContactUs extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public ContactUs() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userName=request.getParameter("name");
		//fetch the value from name field 
		String userEmail=request.getParameter("email");
		String userPhone=request.getParameter("number");
		String userQuestion=request.getParameter("question");
		
		java.util.Date d=new java.util.Date();
		System.out.println("date is"+d);
		
		long dt=d.getTime();
		java.sql.Date sd=new java.sql.Date(dt);
		System.out.println("sql date "+sd);
		
		//create object of bean class
		Contact c=new Contact(userName,userEmail,userPhone,userQuestion,sd);
		//create object of dao class
		CommonDao dao=new CommonDao();
		
		int status=dao.addContact(c);
		if(status>0)
		{
			request.setAttribute("message", "Thankyou for contacting us 🙌🙌");

			RequestDispatcher rd=request.getRequestDispatcher("/jsp/contact_us.jsp");
			
			rd.forward(request, response);
		}
		
	}

}
