package runner.admin.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import runner.dao.AdminDao;




@WebServlet("/AdminLogin")
public class AdminLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public AdminLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String projectPath=request.getContextPath();
		String adminEmail=request.getParameter("email").trim();
		String adminPass=request.getParameter("password");
		
		
		System.out.println("admin email is "+adminEmail);
		System.out.println("admin password is "+adminPass);
		
		if (adminEmail.equalsIgnoreCase("manisrivastav81@gmail.com") && adminPass.equals("mani")) 
		{
			HttpSession hs=request.getSession();
			hs.setAttribute("sessionKey",adminEmail);
			hs.setAttribute("role","admin");			
			response.sendRedirect(projectPath+"/admin/admin_home.jsp");
		}
		else
		{
			request.setAttribute("message","Invalid Email and Password");
			RequestDispatcher rd=request.getRequestDispatcher("/admin/admin_login.jsp");
			rd.forward(request, response);
		}
	}

}
