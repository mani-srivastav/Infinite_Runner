package runner.admin.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import runner.dao.AdminDao;


@WebServlet("/DeleteContact")
public class DeleteContact extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public DeleteContact() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
String[]array=request.getParameterValues("chk");//it is used to fetch values from checkbox
		
		AdminDao dao=new AdminDao();
		int status=dao.deleteContact(array);
		if(status>0)
			response.sendRedirect("/MarkDownEditor/admin/all_contacts.jsp");

	}

}
